function sidebar() {

return `<div id="bar">
<p>Home</p>
<p>Login</p>
<input type="text" id="searchbar">
<p>News</p>
</div>`
    // return your html component here
    //Make sure to give input search box id as ""
}
export default sidebar